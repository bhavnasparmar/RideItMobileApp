export interface modalItemType {
  onPress: () => void;
  selectedItemData : any
}
