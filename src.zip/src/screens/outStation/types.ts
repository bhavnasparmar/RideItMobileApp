import {ImageSourcePropType} from 'react-native';

export interface OutStationType {
  item: {
    id: number;
    title: string;
    img: ImageSourcePropType;
  };
}
