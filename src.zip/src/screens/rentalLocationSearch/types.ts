export interface PickUpDetailProps {
  bgColor?: string;
  activeField?:string;
}
