export interface LocationItem {
  id: number;
  title: string;
}
