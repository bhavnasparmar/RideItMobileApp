export interface AuthTextProps {
  title: string;
  subtitle: string;
}
