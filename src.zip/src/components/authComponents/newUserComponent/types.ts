export interface NewUserTextProps {
  title?: string;
  subtitle?: string;
  onPress?: () => void;
}