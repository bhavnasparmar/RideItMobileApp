import {ReactNode} from 'react';

export interface SocialButtonProps {
  value: ReactNode;
  title: string;
}
