import { ReactNode } from 'react';

export interface AuthContainerProps {
  container: ReactNode;
  topSpace: any,
  imageShow: boolean,
}
