export const vehicleType = 'vehicleType/locations'
export const allvehicle = 'vehicleType'