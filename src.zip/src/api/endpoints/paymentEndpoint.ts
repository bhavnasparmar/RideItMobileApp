export const payment = 'payment-methods'
export const verify_payment = 'ride/verify-payment'