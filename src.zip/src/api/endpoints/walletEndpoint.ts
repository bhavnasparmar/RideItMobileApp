export const riderWallet = 'riderWallet/history'
export const topUpWallet = 'rider/top-up'