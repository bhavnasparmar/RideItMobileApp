export const rideRequest = "rideRequest";
export const rideLocation = "ride-location";
