export const ambulance = "driver/ambulance";
export const ambulanceRequest = "ambulance/rideRequest";
