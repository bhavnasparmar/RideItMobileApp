export const currency = "currency";
export const address = "address";
export const settings = "settings";
export const language = "language";
export const translate = "translate/rider-app";
export const taxidoSetting = "taxido/settings?type=rider";
