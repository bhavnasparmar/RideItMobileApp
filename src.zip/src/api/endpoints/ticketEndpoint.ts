export const priority = "priority";
export const department = "department";
export const ticket = "tickets";
export const message = "ticket";
