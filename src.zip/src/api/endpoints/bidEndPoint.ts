export const bid = 'bid'
