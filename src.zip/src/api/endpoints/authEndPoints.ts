export const login = "rider/login";
export const register = "rider/register";
export const verifyOtp = "rider/verify-token";
export const userSelf = "self";
export const mailLogin = "rider/email/login";
