export const userSelf = "rider/self";
export const editProfile = "updateProfile";
export const changePassword = "updatePassword";
export const deleteAccount = "deleteAccount";
