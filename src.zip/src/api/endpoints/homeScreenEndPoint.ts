export const homeScreen = "home-screen";
