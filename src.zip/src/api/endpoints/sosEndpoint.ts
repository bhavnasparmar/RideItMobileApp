export const sos = "sos";
export const sosAlert = "sos-alert";
