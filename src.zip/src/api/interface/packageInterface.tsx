export interface PackageInterface {
    packageList?: PackageListInterface;
    success?: boolean;
    loading?: boolean;
}

export interface PackageListInterface {

}
