export interface CancelationInterface {
    success?: boolean;
    cancelationValue?: cancelationDataInterface;
    loading?: boolean
}


export interface cancelationDataInterface{

}