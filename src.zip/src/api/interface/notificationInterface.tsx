export interface NotificationInterface {
    notificationList?: NotificationListInterface;
    success?: boolean;
    loading?: boolean;
}

export interface NotificationListInterface {

}
