export interface HomeScreenInterface {
    homeScreenData?: HomeScreenDataInterface;
    homeScreenDataPrimary?: HomeScreenDataPrimaryInterface;
    success?: boolean;
    loading?: boolean;
}
