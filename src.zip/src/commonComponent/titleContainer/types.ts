export interface TitleProps {
  title: string;
}
