export interface solidLineProps {
  width?: number | string | 'auto';
  height?: number;
  color?: string;
  marginVertical?: number;
}
