export interface RadioButtonProps {
  onPress: () => void;
  checked: boolean;
  color: string;
}
