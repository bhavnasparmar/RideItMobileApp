export interface VerticalLineType {
  dynamicHeight: any;
}
