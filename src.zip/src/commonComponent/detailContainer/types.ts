import {ReactNode} from 'react';

export interface DetailContainerProps {
  title: string;
  value: ReactNode;
}
