export interface HeaderTabProps {
  tabName: string;
}
