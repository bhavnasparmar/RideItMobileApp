import {ReactNode} from 'react';

export interface HeaderTypes {
  value?: string;
  container?: ReactNode;
  backgroundColor?:string;
}
