interface SvgComponentProps {
    color: string;
}
export default SvgComponentProps