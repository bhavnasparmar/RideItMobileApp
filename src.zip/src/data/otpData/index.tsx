export const otpData: Array<{id: number; number: number}> = [
  {
    id: 0,
    number: 2,
  },
  {
    id: 0,
    number: 9,
  },
  {
    id: 0,
    number: 6,
  },
  {
    id: 0,
    number: 8,
  },
];
