export const modelData = [
  {
    id: 0,
    title: 'rentalRide.title1',
    subtitle: 'rentalRide.subTitle1',
  },
  {
    id: 1,
    title: 'rentalRide.title2',
    subtitle: 'rentalRide.subTitle2',
  },
  {
    id: 2,
    title: 'rentalRide.title3',
    subtitle: 'rentalRide.subTitle3',
  },
];
export const feesPolicies = [
  {
    id: 0,
    title: 'rentalRide.title4',
    subtitle:
      'rentalRide.subTitle4',
  },
  {
    id: 2,
    title: 'rentalRide.title5',
    subtitle:
      'rentalRide.subTitle5',
  },
];
