
export const termsData = [
  {
    id: 0,
    title: 'selectRide.subTitle',
  },
  {
    id: 1,
    title: 'selectRide.subTitle',
  },
  {
    id: 2,
    title: 'selectRide.subTitle',
  },
  {
    id: 3,
    title: 'selectRide.subTitle',
  },
];
